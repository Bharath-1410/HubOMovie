export const  API_KEY =  "29e3ed0e0d505c27ab18577a513ef5be";
export const TMBD_BASE_URL = "https://api.themoviedb.org/3"